import React from "react";

export default function Contact() {
  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
      {/* ... */}
    </div>
  );
}
